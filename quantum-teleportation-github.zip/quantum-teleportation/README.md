# Quantum Teleportation Simulator

Single-qubit quantum teleportation using the three-qubit protocol, with noise models,
fidelity and success-rate analysis, and a noise-reduction mode.

Author: Sarvesh Salvi (FY B.Tech ECS) - Basics of Quantum Technologies, SLA 1 / SLA 2

## What is in this repository

| Folder / file | What it is |
|---|---|
| `index.html` | The website dashboard (open it in any browser, no install needed) |
| `wokwi/` | Arduino Uno + TFT simulation for wokwi.com (`sketch.ino`, `diagram.json`, `libraries.txt`) |
| `vscode-platformio/` | Same Arduino project as a PlatformIO + Wokwi-for-VS-Code project |
| `python/` | Density-matrix version (`teleport.py`, `noise.py`) and graph script (`experiment.py`) |

## The protocol (three qubits)

* qubit 0 = unknown state |psi> held by Alice
* qubit 1 = Alice's half of a Bell pair, qubit 2 = Bob's half
* Alice applies CNOT(0,1) and H(0), measures qubits 0 and 1 and sends the 2 classical bits
* Bob applies X if the second bit is 1 and Z if the first bit is 1
* Fidelity F = |<psi|Bob>|^2.  Classical limit = 2/3.  Success = qubit arrives and F > 2/3

## Noise models

1. **Depolarizing noise** on Bob's half of the Bell pair (probability = noise level). Average fidelity F = 1 - noise/2, so the link stops beating classical communication at about 67 % noise.
2. **Qubit loss** (10 %): the qubit never arrives.
3. **Classical bit-flip** (5 %): each of the 2 bits can flip, so Bob applies a wrong correction.

## Noise reduction

* Entanglement purification (2 rounds, BBPSSW formula) - works only while the pair fidelity is above 1/2
* Each classical bit sent 3 times with majority vote
* Lost qubit re-sent up to 3 times

## Run it

**Website:** open `index.html`, or publish it with GitHub Pages (below).

**Wokwi (web):** wokwi.com -> New Project -> Arduino Uno, paste the 3 files from `wokwi/`, press Play.
Controls: pot = noise, D2 state, D3 start, D4 graph sweep, D5 noise model, A2 noise reduction.

**Wokwi (VS Code):** open `vscode-platformio/`, install PlatformIO, run Build, then F1 -> "Wokwi: Start Simulator".

**Python:** `pip install numpy matplotlib`, then `python python/teleport.py` (self-test, must give F = 1.0) and `python python/experiment.py` (graphs).

## Publish the website with GitHub Pages

1. Create a new repository on GitHub and upload all these files.
2. Settings -> Pages -> Source: "Deploy from a branch" -> Branch: `main`, folder `/ (root)` -> Save.
3. After a minute the site is live at `https://<your-username>.github.io/<repo-name>/`.
